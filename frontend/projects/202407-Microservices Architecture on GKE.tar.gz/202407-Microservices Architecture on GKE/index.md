---
title: "Deploying Microservice to GKE"
date: 2024-07-14
draft: false
summary: ""
showSummary : false
# categories: ["Project"]
tags: ["Under Construction", "Progress: 75%"]
groupByYear : false
# weight:
authors:
  - Chetan Thapliyal
---

{{< github repo="ChetanThapliyal/microservices-ecommerce-cicd">}}
<br>
{{< button href="https://blog.chetan-thapliyal.cloud/series/cloud-devops-projects" target="_blank" >}}
Blog Post
{{< /button >}}


## Introduction

Automation, development and deployment processes of a microservice-based e-commerce application using Google Kubernetes Engine (GKE) and Google Cloud Platform (GCP). This project demonstrates the challenges faced, the solutions implemented, the technologies used, and provides references and links to the resources leveraged during the project.

## Challenges

1. **Scalability and Maintenance:**
   - Managing multiple microservices efficiently (11 microservices).
   - Ensuring each service can scale independently.

2. **Security:**
   - Configuring secure access and permissions for different services.
   - Implementing robust policies for access control.

3. **Automation:**
   - Setting up CI/CD pipelines for each microservice.
   - Automating the deployment process to minimize manual intervention.

4. **Infrastructure Management:**
   - Setting up and managing the Kubernetes cluster on GKE.
   - Autoscaling worker nodes based on demand.

5. **Integration:**
   - Integrating various tools like Jenkins, Docker, and GKE.
   - Ensuring seamless communication between microservices.

## Solution

1. **Microservice Setup and CI/CD Pipelines:**
   - Each microservice was set up with a dedicated CI/CD pipeline.
   - Automated triggers were configured for changes in the GitHub repository.

2. **Security Enhancements:**
   - Configured VPC (Virtual Private Cloud) and Firewall rules to control access.
   - IAM roles and policies were set up for GKE user, and service account keys were created for authentication.

3. **Infrastructure Automation:**
   - Kubernetes cluster was set up using gcloud and kubectl.
   - Infrastructure as Code (IaC) was implemented using Google Cloud Deployment Manager.

4. **Autoscaling and Node Management:**
   - Worker nodes were configured to auto-scale based on demand using GKE's autoscaling features.
   - Persistent Disk volumes and SSH access were set up for efficient management.

5. **Tool Integration:**
   - Jenkins was set up with Docker and Kubernetes plugins for pipeline creation.
   - Docker images were built, tagged, and pushed to Google Container Registry (GCR) through Jenkins pipelines.

6. **Deployment and Services Configuration:**
   - Different types of Kubernetes services, like NodePort and LoadBalancer, were configured.
   - A microservice deployment service was set up for orchestrating deployments.

## Technologies Used

<p align="left">
  <a>
    <img src="https://skillicons.dev/icons?i=gcp,kubernetes,jenkins,docker,go,git,github,bash&theme=dark" width="800" height="500"/>
  </a>
</p>

## References and Links

  - [GKE Documentation](https://cloud.google.com/kubernetes-engine/docs)
  - [Jenkins Pipeline Documentation](https://www.jenkins.io/doc/book/pipeline/)
  - [Kubernetes Documentation](https://kubernetes.io/docs/home/)
  - [gcloud SDK](https://cloud.google.com/sdk/docs/install)
  - [kubectl Installation Guide](https://kubernetes.io/docs/tasks/tools/install-kubectl/)



